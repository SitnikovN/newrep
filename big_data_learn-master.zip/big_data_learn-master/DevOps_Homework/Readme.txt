all tasks are done with the help of documentation:
https://docs.docker.com/engine/api/

