the work was done using HUE service.

For the task i preferred just to setup an external table out of space saving purposes. 
